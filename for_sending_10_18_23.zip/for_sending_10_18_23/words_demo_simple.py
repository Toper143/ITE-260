import time
import random

with open("./popular.txt") as file:
    words = file.read().split("\n")
    new_words = [word.lower() for word in filter(
        lambda word: 
            all([letter.lower() in "abcdefghijklmnopqrstuvwxyz" for letter in word]) and 
            5 <= len(word),
        words
    )]

    def anagrams(words):
        # very efficient :) even more efficient than the solutions online
        scrambled_dict = {}
        anagram_dict = {}

        for word in new_words:
            sorted_word = "".join(sorted(word))
            if sorted_word not in scrambled_dict:
                scrambled_dict[sorted_word] = [word]
            else:
                scrambled_dict[sorted_word].append(word)
        for sorted_word in scrambled_dict:
            if len(scrambled_dict[sorted_word]) > 1:
                anagram_dict[sorted_word] = scrambled_dict[sorted_word]

        return anagram_dict

    anagrams_dict = anagrams(new_words)

    def anagram_generator():
        key = random.sample(list(anagrams_dict.keys()), 1)[0]
        return [key, anagrams_dict[key]]

    def shuffle(word):
        return "".join(random.sample(word, k = len(word)))